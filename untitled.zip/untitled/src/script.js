const prices = {
1:110,
2:108,
3:105,
4:100,
5:95,
6:90,
7:85,
8:80,
9:75,
10:90,
11:85,
12:80,
13:70,
14:65,
15:60,
16:55,
17:50,
18:45,
19:40,
20:0
};

function calc(){
    let lvl = parseInt(document.getElementById("lvl").value);
    let resultBox = document.getElementById("result");

    if(isNaN(lvl) || lvl < 1 || lvl > 20){
        resultBox.innerText = "دخل لفل من 1 لـ 20 بس";
        return;
    }

    resultBox.innerText =
    "السعر من لفل " + lvl + " إلى 20 = " + prices[lvl] + " جنيه";
}